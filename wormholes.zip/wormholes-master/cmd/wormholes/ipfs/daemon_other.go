// +build !linux

package ipfs

func notifyReady() {}

func notifyStopping() {}
